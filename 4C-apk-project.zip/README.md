# 4C

Read-only 4chan reader as an Android app. No server needed: the app fetches data with Android's own
networking, so the browser CORS rule does not apply.

## Build the APK (free, on GitHub)
1. Create a new **private** repository on GitHub (private, because `resources/debug.keystore` is a debug signing key).
2. Upload everything in this folder to it, keeping the folder structure (including the hidden `.github` folder).
3. Open the repo -> **Actions** -> **Build APK** -> **Run workflow**. It takes about 5-8 minutes.
4. When it finishes, either
   - open the repo's **Releases** page -> **4C latest build** -> download `4C.apk`, or
   - open the finished run -> **Artifacts** -> `4C-apk` (a zip containing the APK).
5. Open the APK on your phone and allow "install unknown apps" when asked.

Later builds install over the old one (same signing key). To update the app, change `www/index.html`
and run the workflow again.

## Files
- `www/index.html`  the whole app
- `capacitor.config.json`, `package.json`  app settings and dependencies
- `scripts/prepare-android.sh`  puts the clover icon, splash and signing key into the Android project
- `.github/workflows/build.yml`  the build recipe
