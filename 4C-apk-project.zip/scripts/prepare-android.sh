#!/usr/bin/env bash
# Runs after `npx cap add android`: installs the clover icon + splash and the fixed signing key.
set -euo pipefail
RES=android/app/src/main/res
test -d "$RES" || { echo "android project not found"; exit 1; }

# launcher icons (plain PNGs; drop the template's adaptive-icon xml so ours is used)
rm -rf "$RES"/mipmap-anydpi-v26
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$RES/mipmap-$d"
  cp resources/android/mipmap-$d/ic_launcher.png       "$RES/mipmap-$d/ic_launcher.png"
  cp resources/android/mipmap-$d/ic_launcher_round.png "$RES/mipmap-$d/ic_launcher_round.png"
  rm -f "$RES/mipmap-$d/ic_launcher_foreground.png"
done

# splash screen images
find "$RES" -name 'splash.png' | while read -r f; do
  case "$f" in
    *land*) cp resources/splash-land.png "$f" ;;
    *)      cp resources/splash.png "$f" ;;
  esac
done

# fixed debug signing key => every build can be installed over the previous one
mkdir -p "$HOME/.android"
cp resources/debug.keystore "$HOME/.android/debug.keystore"
echo "prepared:"; find "$RES" -name 'ic_launcher*.png' | wc -l
